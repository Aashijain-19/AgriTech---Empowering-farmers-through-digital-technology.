# AgriTech — Empowering Farmers Through Digital Technology

AgriTech is a full-stack MERN web application designed to bring practical farming workflows into one place. The project includes user authentication, farm management, crop information, weather access, agricultural product discovery, order-related pages, a community forum, and administration features.

> **Project status:** Academic prototype. Check each feature in the current build before describing it as production-ready. Weather integration depends on valid provider configuration. Advanced AI diagnosis, guaranteed yield prediction, live payments, and production deployment are not claimed as implemented unless separately verified.

## Features

- **User accounts:** Registration and login.
- **Farm management:** Store and view farm records through protected API routes.
- **Crop information:** Browse crop-related information.
- **Weather:** Weather page for location-based information when the external API is configured.
- **Resource shop:** Browse agricultural products.
- **Orders:** Access order-related workflows supported by the current build.
- **Community forum:** View and use supported farming discussion features.
- **Admin area:** Administrative interface and related backend components.
- **MERN architecture:** React + Vite, Node.js, Express, MongoDB, and Mongoose.

## Technology stack

| Layer | Technologies |
|---|---|
| Frontend | React, Vite, React Router, CSS/Bootstrap where included |
| Backend | Node.js, Express.js |
| Database | MongoDB, Mongoose |
| Authentication | bcryptjs and JSON Web Tokens where configured |
| API style | REST/JSON |
| Version control | Git and GitHub |

## Repository structure

```text
AgriTech/
├── client/                 # React + Vite frontend
├── server/                 # Express backend
│   ├── controllers/
│   ├── db/
│   ├── middleware/
│   ├── models/
│   └── routes/
├── docs/
│   ├── Phase-1-Ideation/
│   ├── Phase-2-Project-Planning/
│   ├── Phase-3-Requirement-Analysis/
│   ├── Phase-4-Project-Design/
│   ├── Phase-5-Testing/
│   └── diagrams/
├── .gitignore
└── README.md
```

## Prerequisites

- Node.js and npm
- MongoDB running locally or a MongoDB connection string
- Git (optional, for cloning)
- A weather API key if the weather feature requires one

## Local setup

### 1. Clone the repository

```bash
git clone https://github.com/Aashijain-19/AgriTech---Empowering-farmers-through-digital-technology..git
cd AgriTech---Empowering-farmers-through-digital-technology..
```

If your actual repository folder name differs, use the folder created by `git clone`.

### 2. Configure the backend

```bash
cd server
npm install
```

Create a local `.env` file in `server/` using `server/.env.example` as a reference. Use the variable names expected by `server/db/config.js` and `server/index.js`. Example placeholders only:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/agritech
JWT_SECRET=replace_with_a_long_random_secret
CLIENT_URL=http://localhost:5173
```

Do not copy real secrets into this README or commit the `.env` file. If the project uses additional environment variables, document their names and purpose in `server/.env.example`.

Start the backend:

```bash
npm run dev
```

### 3. Configure the frontend

Open a second terminal:

```bash
cd client
npm install
npm run dev
```

Open the local URL printed by Vite (commonly `http://localhost:5173`; if that port is busy, Vite may choose another port). Ensure the frontend API base URL points to the backend URL expected by the current code.

### 4. Database and seed data

Ensure MongoDB is running and the configured database URI is correct. If the project includes a seed script, inspect its source and run it only when you intend to insert its sample data:

```bash
cd server
npm run seed
```

Use only development/test accounts. Change any sample credentials before deployment.

## Documentation

Project phase documents are in [`docs/`](docs/):

1. **Phase 1 — Ideation:** empathy map, problem statements, brainstorming and prioritization.
2. **Phase 2 — Project Planning:** backlog, user stories, sprint plan, risks.
3. **Phase 3 — Requirement Analysis:** functional/non-functional requirements, technology stack, DFD and user stories.
4. **Phase 4 — Project Design:** proposed solution, problem–solution fit, solution architecture.
5. **Phase 5 — Testing:** User Acceptance Testing (UAT) template and test cases.

Diagrams are provided in `docs/diagrams/` as PNG images and editable Mermaid source files.

## Testing

Use the UAT document in `docs/Phase-5-Testing/`. Test results are intentionally left as **Not Run** until the cases have been executed. Record actual results, bugs, and evidence instead of assuming all tests pass.

Suggested checks:
- Registration/login and invalid credentials
- Protected API calls with and without a token
- Creating and listing a user's farms
- Weather provider success/failure states
- Product/order and forum workflows
- Admin authorization
- Responsive UI and backend error handling

## Security notes

- Never commit `.env`, API keys, database credentials, JWT secrets, access tokens, or real user data.
- Keep `.env.example` files limited to placeholder values.
- Hash passwords and enforce authentication/ownership checks on the server.
- If a real secret was ever committed, rotate it. Removing it from the current file does not remove it from Git history.
- Do not use sample admin credentials in a public deployment.

## Current limitations and future enhancements

Potential future work, subject to data and user validation:
- Localized crop guidance and verified pest alerts
- Expert consultation workflow
- Crop-stage history and analytics
- More complete role-based admin controls
- Deployment with managed MongoDB and secure environment configuration
- Additional automated tests and performance measurements

## Author / academic details

- **Project:** AgriTech — Empowering Farmers Through Digital Technology
- **Student / Team ID:** To be filled in
- **College / Department:** To be filled in
- **Project Guide:** To be filled in
